TOKEN = "6263997575:AAHq2aY1mEpyzx0ZMVXURr1QnXTA7nEFNwA"
keys = {
    'евро': 'EUR',
    'рубль': 'RUB',
    'доллар': 'USD',
}